package com.matariky.commonservice.base.vo;

import com.matariky.model.QueryDataIsolation;
import lombok.Data;

@Data
public class CodeOptionListVO extends QueryDataIsolation {

    private Long typeId;
}
