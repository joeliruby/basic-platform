package com.matariky.commonservice.area.bean;

public class CommonAreaVo extends CommonArea{
	private Integer childrenNo;

	public Integer getChildrenNo() {
		return childrenNo;
	}

	public void setChildrenNo(Integer childrenNo) {
		this.childrenNo = childrenNo;
	}

}
