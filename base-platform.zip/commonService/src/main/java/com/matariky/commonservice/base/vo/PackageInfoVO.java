package com.matariky.commonservice.base.vo;

import lombok.Data;

@Data
public class PackageInfoVO {

    private String packageVersion;

    private Long packageId;
}
