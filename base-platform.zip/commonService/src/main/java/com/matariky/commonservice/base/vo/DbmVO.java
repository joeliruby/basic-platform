package com.matariky.commonservice.base.vo;

import lombok.Data;

@Data
public class DbmVO {

    private String value;

    private String label;
}
