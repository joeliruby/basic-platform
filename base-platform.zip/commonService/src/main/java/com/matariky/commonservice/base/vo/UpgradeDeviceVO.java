package com.matariky.commonservice.base.vo;


import lombok.Data;

@Data
public class UpgradeDeviceVO {

    private Long deviceId;

    private String deviceCode;

    private String deviceModel;
}
