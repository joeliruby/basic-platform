package com.matariky.commonservice.base.vo;

import lombok.Data;

import java.util.List;

@Data
public class DeviceUpgradeListVO {

    private List<Long> idList;

}
