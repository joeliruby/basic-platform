package com.matariky.commonservice.base.vo;

import lombok.Data;

@Data
public class BasicBaseAntifakeDetailVO {
	private Long validationTimeStart;
	
	private Long validationTimeEnd;

	private String goodsCode;
	
	private String goodsName;



	
}
