package com.matariky.commonservice.base.vo;


import lombok.Data;

@Data
public class DeviceIdVO {

    private Long deviceId;

    private String deviceCode;

}
