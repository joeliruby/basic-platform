package com.matariky.aop;

public interface GetCurrentRequest {

}