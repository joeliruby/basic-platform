ssh 192.168.0.212 "sh /opt/builddelta.sh"
exit



