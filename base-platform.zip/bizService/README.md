# jimureport-demo

积木报表集成示例代码。

```
集成示例，采用mysql5.7数据库
```




使用步骤
-----------------------------------

-  第一步：创建数据库 jeecg-boot（采用utf8mb4编码）
   
-  第二步：执行初始化脚步

           https://github.com/zhangdaiscott/JimuReport/blob/master/db/jimureport.mysql5_7.create.sql
-  第三步： 启动项目

           右键执行com.example.jmreport.JimuReportDemoApplication
-  第四步： 访问项目

           http://localhost:8085/jeecg-boot/jmreport/list
           






